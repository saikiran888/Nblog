To run The blog-post app:
->install all the dependencies 
->start the mongodb : /Users/mandulasaikiran/mongodb/bin/mongod.exe --dbpath=/Users/mandulasaikiran/mongodb-data
->start the app:npm run devStart